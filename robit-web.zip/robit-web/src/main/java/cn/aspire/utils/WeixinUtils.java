package cn.aspire.utils;

import java.io.IOException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.google.gson.Gson;

import cn.aspire.menu.Menu;
import net.sf.json.JSONObject;

/**
 * 微信的工具类
 * @author Administrator
 *
 */
public class WeixinUtils {
	private static Logger log = LogManager.getLogger(WeixinUtils.class);
	private static String url =  "https://api.weixin.qq.com/cgi-bin/menu/create?access_token={ACCESS_TOKEN}";
	/**
	 * 字定义创建菜单
	 * 
	 * @param menu 菜单对象 
	 * @param accessToken 
	 * @return 0 表示成功 其他表示失败
	 */
	public static int createMenu(Menu menu, String accessToken) { 
		//url地址 
		url = url.replace("{ACCESS_TOKEN}", accessToken);
		log.info("替换后的url为 ： " + url );
		//准备参数  将其转化为json字符串 
		String menuStr = new Gson().toJson(menu);
		log.info("参数 转化为json字符串 menuStr = "+ menuStr);
		//调用方法进行post请求，得到结果，把结果进行比较 
		JSONObject httpRequest = null;
		try {
			 httpRequest = HttpUtils.httpRequest(url, "POST", menuStr);
		} catch (IOException e) {
			log.error("调用失败 ",e);
			e.printStackTrace();
		}
		//如果成功则返回0
		if(null != httpRequest ){
			Integer errcode = (Integer)httpRequest.get("errcode");
			if(0!=errcode){
				log.error("调用结果失败 errcode =  "+ errcode + " errmsg = " + httpRequest.get("errmsg"));
				return 1;
			}
			return 0;
		}
		return 1;
	}
	
	
}
