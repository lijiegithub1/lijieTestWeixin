package cn.aspire.utils;

import java.io.IOException;
import java.net.URLEncoder;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import cn.aspire.pojo.AccessToken;
import net.sf.json.JSONObject;

public class MAIN {
	private static Logger log = LogManager.getLogger(MAIN.class);
	public static void main(String[] args) throws IOException {
		 String encode = URLEncoder.encode("aaa///", "UTF-8");
		System.out.println(encode);
	}
}
