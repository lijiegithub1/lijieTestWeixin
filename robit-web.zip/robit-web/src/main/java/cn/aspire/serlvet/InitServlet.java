package cn.aspire.serlvet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import cn.aspire.utils.TokenThread;

public class InitServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;  
	private static Logger logger = LogManager.getLogger(InitServlet.class);
	private static ServletContext application ;
    public void init() throws ServletException {  
    	//在初始化的时候去servletcontent
    	application =this.getServletContext();
        // 获取web.xml中配置的参数  
        String  appid  = getInitParameter("appid");  
        String  appsecret = getInitParameter("appsecret");
        
        if (StringUtils.isBlank(appid) || StringUtils.isBlank(appsecret)) {
        	logger.warn("appid and appsecret is not blank. appid="+appid + ", appsecret="+appsecret);
        	return;
        }
        
        TokenThread tokenThread = new TokenThread();
        tokenThread.setAppid(appid);
        tokenThread.setAppsecret(appsecret);
        new Thread(tokenThread).start();
    }
	public static ServletContext getApplication() {
		return application;
	}
    
}
