package cn.aspire.serlvet;

import javax.servlet.ServletContext;

public class MAIN {
	public static void main(String[] args) {
		ServletContext application = InitServlet.getApplication();
		System.out.println(application.getContextPath());
	}
}
