package cn.aspire.controller;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Date;

import javax.print.attribute.standard.Media;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import cn.aspire.dao.ImageMapper;
import cn.aspire.source.Image;
import cn.aspire.utils.TokenThread;
import net.sf.json.JSONObject;

@Controller
public class createController {
	@Autowired
	private ImageMapper imageMapper;
	@RequestMapping("/")
	public String showIndex(){
		System.out.println("aaa");
		return "index";
		
	}
	
	
	@RequestMapping("/create")
    public void create(@RequestParam("file") CommonsMultipartFile file,HttpServletRequest request){
       try {
   			String accessToken = TokenThread.accessToken.getAccess_token();
            String fileName = file.getOriginalFilename();
            fileName = URLEncoder.encode(fileName, "UTF-8");// 进行中文处理
            String UPLOAD_PATH = File.separator + "upload" + File.separator + "img" + File.separator;
            String path = request.getSession().getServletContext().getRealPath(UPLOAD_PATH);
            String pathFileName = path + File.separator + fileName;
            JSONObject mediaJson = addMaterialEver(pathFileName, "image", accessToken);
           if (mediaJson != null) {
        	   System.out.println("mediaJson type"+ mediaJson.get("type"));
        	   System.out.println("mediaJson media_id"+ mediaJson.get("media_id"));
        	   System.out.println("mediaJson created_at"+ mediaJson.get("created_at"));
        	   //创建素材的类 
        	   Image image = new Image();
        	   image.setKeyWord("小智机器人的照片");
        	   image.setMedieId((String)mediaJson.get("media_id"));
        	   //将其放到数据库中 
        	   try {
        		   imageMapper.saveImage(image);
        		   System.out.println("上传成功");
			} catch (Exception e) {
				e.printStackTrace();
			}
        	   
            } 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
/**
     * 上传其他永久素材(图片素材的上限为5000，其他类型为1000)
     *
     * @return
     * @throws Exception
     */
   public  JSONObject addMaterialEver(String fileurl, String type, String token) {
	   System.out.println("进到方法 addMaterialEver ");
        try {
            File file = new File(fileurl);
            //上传素材
            String path = "https://api.weixin.qq.com/cgi-bin/media/upload?access_token=" + token + "&type=" + type;
            String result = connectHttpsByPost(path, null, file);
            System.out.println("result ==>" + result);
            result = result.replaceAll("[\\\\]", "");
            System.out.println("result:" + result);
            JSONObject resultJSON = JSONObject.fromObject(result);
            if (resultJSON != null) {
                if (resultJSON.get("media_id") != null) {
                	System.out.println("media_id"  + resultJSON.get("media_id"));
                    System.out.println("上传" + type + "永久素材成功");
                    return resultJSON;
                } else {
                    Integer errcode = (Integer) resultJSON.get("errcode");
                    if(errcode -40001 == 0 ){
                    }
                    System.out.println("上传" + type + "永久素材失败");
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
        } 
        return null;
    }
    
    
   public static  String connectHttpsByPost(String path, String KK, File file) throws IOException, NoSuchAlgorithmException, NoSuchProviderException, KeyManagementException {
        URL urlObj = new URL(path);
        //连接
        HttpURLConnection con = (HttpURLConnection) urlObj.openConnection();
        String result = null;
        con.setDoInput(true);

        con.setDoOutput(true);

        con.setUseCaches(false); // post方式不能使用缓存

        // 设置请求头信息
        con.setRequestProperty("Connection", "Keep-Alive");
        con.setRequestProperty("Charset", "UTF-8");
        // 设置边界
        String BOUNDARY = "----------" + System.currentTimeMillis();
        con.setRequestProperty("Content-Type",
                "multipart/form-data; boundary="
                        + BOUNDARY);

        // 请求正文信息
        // 第一部分：
        StringBuilder sb = new StringBuilder();
        sb.append("--"); // 必须多两道线
        sb.append(BOUNDARY);
        sb.append("\r\n");
        sb.append("Content-Disposition: form-data;name=\"media\";filelength=\"" + file.length() + "\";filename=\""

                + file.getName() + "\"\r\n");
        sb.append("Content-Type:application/octet-stream\r\n\r\n");
        byte[] head = sb.toString().getBytes("utf-8");
        // 获得输出流
        OutputStream out = new DataOutputStream(con.getOutputStream());
        // 输出表头
        out.write(head);

        // 文件正文部分
        // 把文件已流文件的方式 推入到url中
        DataInputStream in = new DataInputStream(new FileInputStream(file));
        int bytes = 0;
        byte[] bufferOut = new byte[1024];
        while ((bytes = in.read(bufferOut)) != -1) {
            out.write(bufferOut, 0, bytes);
        }
        in.close();
        // 结尾部分
        byte[] foot = ("\r\n--" + BOUNDARY + "--\r\n").getBytes("utf-8");// 定义最后数据分隔线
        out.write(foot);
        out.flush();
        out.close();
        StringBuffer buffer = new StringBuffer();
        BufferedReader reader = null;
        try {
            // 定义BufferedReader输入流来读取URL的响应
            reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String line = null;
            while ((line = reader.readLine()) != null) {
                buffer.append(line);
            }
            if (result == null) {
                result = buffer.toString();
            }
        } catch (IOException e) {
            System.out.println("发送POST请求出现异常！" + e);
            e.printStackTrace();
        } finally {
            if (reader != null) {
                reader.close();
            }
        }
        return result;
    }
}
