package cn.aspire.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.MethodInvokingJobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.gson.Gson;

import cn.aspire.pojo.auth.Auth;
import cn.aspire.pojo.auth.UserInfo;
import cn.aspire.utils.HttpUtils;
import cn.aspire.utils.MyX509TrustManager;
import net.sf.json.JSONObject;

/**
 * 网页的验证 
 * @author Administrator
 *
 */
@Controller
public class AuthorizeController {
	private static Logger logger = LogManager.getLogger(MenuManager.class);
	private  static String getAccesstokenUrl  = " https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&"
								+ "secret=SECRET&code=CODE&grant_type=authorization_code";
	private static  String getRefeshTokenUrl  = "https://api.weixin.qq.com/sns/oauth2/refresh_token?"
				+ "appid=APPID&grant_type=refresh_token&refresh_token=REFRESH_TOKEN";
	private  static String getUserinfo  = " https://api.weixin.qq.com/sns/userinfo?access_token=ACCESS_TOKEN"
							+ "&openid=OPENID&lang=zh_CN";
	private static  String appid ="wx8dc5ac202f3bc20c" ;
	private static  String secret ="c3f04605748a6aaaf5a9e47c2e3e52d1" ;
	private static String  refresh_token = "";
	private static String  access_token = "";
	private static String  openid = "";
	private static String code ="";
	@RequestMapping("/auth")
	public String getCode(HttpServletRequest request,
			@RequestParam("code") String code){
		logger.info("code==>" + code);
		getAccesstokenUrl = getAccesstokenUrl.replace("APPID", appid);
		getAccesstokenUrl = getAccesstokenUrl.replace("SECRET", secret);
		this.code =code; 
		getAccesstokenUrl = getAccesstokenUrl.replace("CODE", this.code);
		//get请求 
		String getAccesstoken = "";
		try {
			getAccesstoken = httpRequest(getAccesstokenUrl, "GET", "");
			logger.info("getAccesstoken==>" + getAccesstoken);
			System.out.println("getAccesstoken==>" + getAccesstoken);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Auth auth = new Gson().fromJson(getAccesstoken, Auth.class);
		logger.info("auth ==>" + auth);
		refresh_token = auth.getRefresh_token();
		logger.info("refresh_token ==>" + refresh_token);
		openid = auth.getOpenid();
		access_token = auth.getAccess_token();
		
		//拼装参数
		//获得用户信息
		UserInfo userInfo = getUserInfo();
		
		return code; 
		
	}
	/**
	 * 获得用户的信息
	 * @return
	 */
	public UserInfo getUserInfo(){
		//把这几步进行串联一起 
		getUserinfo	 = getUserinfo.replace("ACCESS_TOKEN", access_token);
		getUserinfo	 = getUserinfo.replace("OPENID", openid);
		logger.info("getUserinfo ==>" + getUserinfo);
		String getUserinfoJson= "";
		try {
			getUserinfoJson = httpRequest(getAccesstokenUrl, "GET", "");
			logger.info("getAccesstoken==>" + getUserinfoJson);
			System.out.println("getAccesstoken==>" + getUserinfoJson);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//转成userInfo对象 
		UserInfo userInfo = new Gson().fromJson(getUserinfoJson, UserInfo.class);
		logger.info("userInfo==>" + userInfo);
		return userInfo;
	}
	
	
	/**
	 * 定时任务 
	 * 执行定时任务 
	 */
	public void execute(){
		//只有刷新不为空才进行刷新 
		String getAccesstoken = "";
		logger.info("refresh_token=》" + refresh_token);
		if(StringUtils.isNotBlank(refresh_token)){
			getRefeshTokenUrl = getRefeshTokenUrl.replace("APPID", appid);
			getRefeshTokenUrl = getRefeshTokenUrl.replace("REFRESH_TOKEN", refresh_token);
			try {
				logger.info("getRefeshTokenUrl ==> " +   getRefeshTokenUrl);
				 getAccesstoken = httpRequest(getRefeshTokenUrl, "GET", "");
				logger.info("getAccesstoken==>" + getAccesstoken);
				System.out.println("getAccesstoken==>" + getAccesstoken);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{//当refresh_token为空是进行提示
			logger.warn("refresh_token 值为空 ");
		}
		
		Auth auth = new Gson().fromJson(getAccesstoken, Auth.class);
		logger.info("auth 对象的值为" + auth);
		if(null!=auth){
			openid = auth.getOpenid();
			access_token = auth.getAccess_token();
		}else{
			logger.warn("Auth 为空 ");
		}
	}
	
	
	
	/**
	 * 
	 * @param requestUrl
	 * @param requestMethod
	 * @param requestPamas
	 * @return
	 * @throws IOException
	 */
	public static String  httpRequest (String requestUrl ,String requestMethod,String requestPamas) throws IOException{
        StringBuffer buffer = new StringBuffer();  
		//获取url地址 
		URL url = new URL(requestUrl);
		HttpsURLConnection  conn = (HttpsURLConnection )url.openConnection();
		//设置请求的参数 
		conn.setDoInput(true);
		conn.setDoOutput(true);
		conn.setUseCaches(false); 
		
		  // 创建SSLContext对象，并使用我们指定的信任管理器初始化  
		SSLSocketFactory ssf = null;
        try {
        	TrustManager[] tm = { new MyX509TrustManager() };  
        	SSLContext sslContext = SSLContext.getInstance("SSL", "SunJSSE");  
			sslContext.init(null, tm, new java.security.SecureRandom());
			 ssf = sslContext.getSocketFactory(); 
		} catch (Exception e) {
			e.printStackTrace();
		}  
        // 从上述SSLContext对象中得到SSLSocketFactory对象  
		//安全
		conn.setSSLSocketFactory(ssf);
		//请求的方式
		conn.setRequestMethod(requestMethod);
		if("GET".equals(requestMethod)){
			conn.connect();
		}
		//post进行添加参数
		//1、 如果有参数需要获得out进行输出 
		if(StringUtils.isNotBlank(requestPamas)){
			OutputStream outputStream = conn.getOutputStream();
			outputStream.write(requestPamas.getBytes("UTF-8"));
			outputStream.flush();
		}
		//2 获得输入 inputStream
		InputStream in = conn.getInputStream();
		BufferedReader  br = new BufferedReader(new InputStreamReader(in, "utf-8"));
		String str = null;
		while ((str = br.readLine())!= null) {
			buffer.append(str);
		}
		//最后将其转化为jsonObject对象 
		return buffer.toString();
	}

	
}	
