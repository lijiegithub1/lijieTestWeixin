package cn.aspire.controller;

import java.io.IOException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.google.gson.Gson;

import cn.aspire.pojo.AccessToken;
import cn.aspire.pojo.customer.Customer;
import cn.aspire.utils.HttpUtils;
import cn.aspire.utils.SignUtil;
import net.sf.json.JSONObject;

/**
 * 客服服务
 * @author Administrator
 *
 */
public class CustomerManager {
	private static Logger logger = LogManager.getLogger(MenuManager.class);
	private static String url  = "https://api.weixin.qq.com/customservice/kfaccount/add?access_token=ACCESS_TOKEN";
	
	public static void main(String[] args) throws IOException {
		//获得ACCESS_TOKEN
		String appid ="wx8dc5ac202f3bc20c" ;
		String appsecret ="c3f04605748a6aaaf5a9e47c2e3e52d1";
		AccessToken accessToken = SignUtil.getAccessToken(appid , appsecret);
		logger.info("accessToken ==>" + accessToken);
		//拼装字符串
		//请求的参数 把传json对象
		String requestPamas="";
		Customer customer = new Customer();
		customer.setKf_account("test@shrs455");
		customer.setNickname("小智");
		customer.setPassword("qq5618978455");
		 requestPamas = new Gson().toJson(customer);
		//请求的url
		String requestUrl = url.replace("ACCESS_TOKEN", accessToken.getAccess_token());
		//
		JSONObject httpRequest = HttpUtils.httpRequest(requestUrl , "POST", requestPamas);
		if(null != httpRequest){
			Integer errcode = (Integer)httpRequest.get("errcode");
			if(0 == errcode){
				logger.info("返回正确");
			}else{
				logger.error("返回错误 ==> " + errcode);
			}
		}
	}
	
	
	
}
