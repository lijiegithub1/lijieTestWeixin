package cn.aspire.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.servlet.ServletContext;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.google.gson.Gson;

import cn.aspire.pojo.AccessToken;
import cn.aspire.pojo.customer.Customer;
import cn.aspire.pojo.erweima.ActionInfo;
import cn.aspire.pojo.erweima.ErWeiMa;
import cn.aspire.pojo.erweima.Scene;
import cn.aspire.serlvet.InitServlet;
import cn.aspire.utils.HttpUtils;
import cn.aspire.utils.MyX509TrustManager;
import cn.aspire.utils.SignUtil;
import net.sf.json.JSONObject;

public class ErWeiMaManager {
	private static Logger logger = LogManager.getLogger(MenuManager.class);
	private static String url  = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=TOKENPOST";
	private static String url1  = "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=TICKET";
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws IOException {
		//获得ACCESS_TOKEN
		String appid ="wx8dc5ac202f3bc20c" ;
		String appsecret ="c3f04605748a6aaaf5a9e47c2e3e52d1";
		AccessToken accessToken = SignUtil.getAccessToken(appid , appsecret);
		logger.info("accessToken ==>" + accessToken);
		//拼装字符串
		//请求的参数 把传json对象
		String requestPamas="";
		ErWeiMa erWeiMa = new ErWeiMa();
		ActionInfo actionInfo = new ActionInfo();
		Scene scene = new Scene();
		scene.setScene_id(4294967295L);
		actionInfo.setScene(scene );
		erWeiMa.setAction_info(actionInfo);
		erWeiMa.setAction_name("QR_SCENE");
		erWeiMa.setExpire_seconds(300L);
		 requestPamas = new Gson().toJson(erWeiMa);
		 logger.info("requestPamas ==>" + requestPamas);
		//请求的url
		String requestUrl = url.replace("TOKENPOST", accessToken.getAccess_token());
		logger.info("requestUrl==>" + requestUrl);
		JSONObject httpRequest = HttpUtils.httpRequest(requestUrl , "POST", requestPamas);
		logger.info("httpRequest ==>" + httpRequest);
		/*if(null != httpRequest){
			Integer errcode = (Integer)httpRequest.get("errcode");
			if(0 == errcode){
				logger.info("返回正确");
			}else{
				logger.error("返回错误 ==> " + errcode);
			}
		}*/
		
		//获得参数在去访问 
		
		String ticket = (String)httpRequest.get("ticket");
		logger.info("ticket == >" + ticket );
		logger.info("URLEncoder.encode(ticket) == >" + URLEncoder.encode(ticket) );
		url1 = url1.replace("TICKET", URLEncoder.encode(ticket,"UTF-8"));
		logger.info("url1 == >" + url1);
		 httpRequest1(url1 , "GET", "");
		
		
		
	}
	
	/**
	 * 封装的可以post/get请求的工具类  且对应https 需要一个验证器  ，这个验证器我会写 ，其实就是放到请求中
	 * @param requestUrl 请求的url
	 * @param requestMethod get/post
	 * @param requestPamas post请求携带的参数
	 * @return
	 * @throws IOException 
	 */
	public static void  httpRequest1 (String requestUrl ,String requestMethod,String requestPamas) throws IOException{
		JSONObject jsonObject = null;  
        StringBuffer buffer = new StringBuffer();  
		//获取url地址 
		URL url = new URL(requestUrl);
		HttpsURLConnection  conn = (HttpsURLConnection )url.openConnection();
		//设置请求的参数 
		conn.setDoInput(true);
		conn.setDoOutput(true);
		conn.setUseCaches(false); 
		
		  // 创建SSLContext对象，并使用我们指定的信任管理器初始化  
		SSLSocketFactory ssf = null;
        try {
        	TrustManager[] tm = { new MyX509TrustManager() };  
        	SSLContext sslContext = SSLContext.getInstance("SSL", "SunJSSE");  
			sslContext.init(null, tm, new java.security.SecureRandom());
			 ssf = sslContext.getSocketFactory(); 
		} catch (Exception e) {
			e.printStackTrace();
		}  
        // 从上述SSLContext对象中得到SSLSocketFactory对象  
		//安全
		conn.setSSLSocketFactory(ssf);
		//请求的方式
		conn.setRequestMethod(requestMethod);
		if("GET".equals(requestMethod)){
			conn.connect();
		}
		//post进行添加参数
		//1、 如果有参数需要获得out进行输出 
		if(StringUtils.isNotBlank(requestPamas)){
			OutputStream outputStream = conn.getOutputStream();
			outputStream.write(requestPamas.getBytes("UTF-8"));
			outputStream.flush();
		}
		//先去类型 
		ServletContext application = InitServlet.getApplication();
		logger.info("application ==>" + application);
		String contentType = conn.getContentType();
		logger.info("contentType ==>" + contentType);
		File file = null;
		if(null == application){
			if(StringUtils.isNotBlank(contentType)){
				if(contentType.contains("jpg")){
					//application.getContextPath()+
					file = new File("C:/development/ecpliseTest/robit-manager/robit-web/src/main/webapp/upload/img/erweima.jpg");
				}
			}
			if(!file.exists()){
				 boolean createNewFile = file.createNewFile();
				 if(createNewFile){
					 logger.info("创建成功");
				 }
			}
		}
		
		//2 获得输入 inputStream
		InputStream in = conn.getInputStream();
		IOUtils.copy(in, new FileOutputStream(file));
		//最后将其转化为jsonObject对象 
	}
	
	
}
